
DESCRIPTION:

C implementation of USB driver
serves as a reference to the VHDL code

HW/ - has NIOS II processor config
SW/isp - implementation of USB device

