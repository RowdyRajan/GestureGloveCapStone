Software for group 2 capstone project DE2 board

Files in directory

basic_io.h 
-- Defines some macros for GPIO, 7 SEG Display and Time Delay

basic_typ.h 
-- Defines some aliases for basic types (eg. CHAR)

D13Bus.h 
-- Not sure exaclty, something to do with the D13 Bus. There are not many functions here but they seem fundamental (read/write to buffer, single transmit, burst transmit etc.)

common.h
-- A few bit level macros. IRQ macros. Structs and definitions for a few things. Also fairly fundamental like device_request struct and _IO_REQUEST. _D13FLAGS <- seems important

debug.h
-- A bunch of flags for debug testing are included here. This could be quite useful for checking if each part along the way is working. 


HAL4D13.h  
!!!-- One of the major files. Defines most of the values and functions used for the main interactions with the USB controller. 
	The USB.h file in the app notes from 2014 has most of 		this file (if not all) copied into it. However their 		file also includes some additional things like a 		struct called usb_device.
	Either they created it or it will be within another 		file in the example project.
The functions within this file deal mostly with configuration of various things including Endpoints, Interrupt registers, DMA etc. Also included are connect, setup, write/read endpoint.

hello_world_0.c
-- This file had the main function in the LED_DEVICE example project and it will likely be invaluable in learning how to implement USB communication in our own project. I changed the name of the main function so (hopefully) eclipse won't get confused.

iso.h
-- very small file with three definitions and some iso (I assume isochronous communication related)




