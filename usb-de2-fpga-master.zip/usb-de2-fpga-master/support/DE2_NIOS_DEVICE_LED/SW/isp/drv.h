/*
 * drv.h
 *
 *  Created on: 2012-07-07
 *      Author: mzakharo
 */

#ifndef DRV_H_
#define DRV_H_

//*************************************************************************
// Function Prototypes
//*************************************************************************
void SetupToken_Handler(void);
void DeviceRequest_Handler(void);
void configure_isp(void);
void check_chip_id(void);


#endif /* DRV_H_ */
